Build instructions on Linux:

1 - Create a build folder:
$ mkdir build
$ cd build
2 - Generate make file:
$ cmake -G "Unix Makefiles" ..
3 - Build and configure:
$ cmake --build . --config
4 - Execute:
$ ./Task1App <inputfile path&name> <output path&name>
